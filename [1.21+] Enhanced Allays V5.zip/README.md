# Enhanced-Allays
video: https://youtu.be/Z_L3IO1kkhk?si=l_gVACMcQQD34nGv

- Teleports allays to the their owner if they are 64 blocks away from them, unless nametaged or in a vehicle
- Allays trapped in or above walls, fences, fence gates, composters, (filled) cauldrons and hoppers don't teleport ever
- Teleports allays to their note block if they are outside the 16 m range and their timer runs out, unless nametaged or in a vehicle
  - handy in watery environments where allays are slower
  - has suffocation protection by teleporting them on top of the note block (there is always air above working note blocks)
  - has the following leash functionality to counter this note block feature
- allays leashed by players cannot like note blocks and thus follow the player
- naming an allay "unname" causes it to lose its custom name
- /trigger invulnerable_allays  makes your allays immortal
  - trigger again to make them mortal again

If server owners don't want immortal allays, then go into the data pack file > data > tpallays >  functions and remove invulnerable.mcfunction

### notice
- If you want to support small creators like me, you can turn off ad blocker.
- Check out my profile for more creations: https://modrinth.com/user/TQNL

Keep in mind:
- Ensure you're familiar with installing data packs.
Verify compatibility with your Minecraft version.

Terms of use:

Do:
- Use and modify the data pack for private use.
- Credit me (ThijquintNL) as the creator when using the data pack in public, such as in video showcases, or when editing and redistributing the original material.

Don't:
- Redistribute the data pack for commercial purposes.


Under CC-BY-NC-SA 4.0 license
